package com.practice.leetcode.array;

public class ArrayPalindromic {
public static void main(String[] args) {
	int[] arr = {1,2,1};
	System.out.println(isPalindromic(arr));
}
static boolean isPalindromic(int[] a){
    return isPalindromicHelper(0,a.length-1,a);
}
static boolean isPalindromicHelper(int s,int e,int[] a){
  	return s>e || a[s]==a[e] && isPalindromicHelper(++s,--e,a);
}
}
