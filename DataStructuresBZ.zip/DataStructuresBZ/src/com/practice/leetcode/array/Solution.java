package com.practice.leetcode.array;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Solution {

	public static void main(String[] args) {
		Solution s = new Solution();
//		int arr[] = { 7,7,7,8 }; /*1*/
//		int arr[] = { 1, 2, 3, 4 }; /* 5 */
//		int arr[] = { 6,5,4,3,2,1 }; /*0*/
//		int arr[] = { 7,1,5,3,6,4 }; /*7*/
//		int arr[] = { 1,4,2 }; /*3*/
//		int arr[] = { 2,4,1 }; /*2*/
//		int arr[] = { 2,1,5,7 }; /*6*/
//		int arr[] = {3,3,5,0,0,3,1,4}; /*8*/
//		int arr[] = {3,3,0,5,5,3,4,1}; /*6*/
//		int arr[] = {1,2,4,2,5,7,2,4,9,0}; /*15*/

//		System.out.println(s.maxProfit(arr));

//		s.rotate(arr, 2);
//		System.out.println(Arrays.toString(arr));

//		System.out.println(s.containsDuplicate(arr));

//		int nums1[] = { 4,9,5 };
//		int nums2[] = { 9,4,9,8,4 };
//		System.out.println(Arrays.toString( s.intersect(nums1, nums2)) );

//		int digits[] = {9,9,9,9};
//		int digits[] = {4,3,9,9};
//		System.out.println(Arrays.toString( s.plusOne(digits)) );

//		int nums[] = {0,0,0,0};
//		s.moveZeroes(nums);
//		System.out.println(Arrays.toString( nums ));

//		int nums[] = { 2, 7, 11, 15 };
//		System.out.println(Arrays.toString(s.twoSum(nums, 18)));

//		char[][] board = { { '.', '.', '.', '.', '5', '.', '.', '1', '.' },
//				{ '.', '4', '.', '3', '.', '.', '.', '.', '.' }, { '.', '.', '.', '.', '.', '3', '.', '.', '1' },
//				{ '8', '.', '.', '.', '.', '.', '.', '2', '.' }, { '.', '.', '2', '.', '7', '.', '.', '.', '.' },
//				{ '.', '1', '1', '.', '.', '.', '.', '.', '.' }, { '.', '.', '.', '.', '.', '2', '.', '.', '.' },
//				{ '.', '2', '.', '9', '.', '.', '.', '.', '.' }, { '.', '.', '4', '.', '.', '.', '.', '.', '.' } };
//		System.out.println(s.isValidSudoku(board));
		
//		int[][] matrix = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
		int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
		s.rotate(matrix);
		System.out.println(Arrays.deepToString(matrix));
		
		char c = '\u0908';
		System.out.println(c);
	}

	/**
	 * 1. Remove Duplicates from Sorted Array
	 */
	public int removeDuplicates(int[] nums) {
		int i = 0;
		for (int j = 0; j < nums.length; j++) {
			while (j < nums.length && nums[i] == nums[j])
				j++;
			if (j < nums.length) {
				nums[i + 1] = nums[j];
				i++;
			}
		}
		return i + 1;
	}

	/**
	 * 2. Best Time to Buy and Sell Stock II
	 */
	public int maxProfit(int[] prices) {
		int maxProfit = 0;
		for (int i = 1; i < prices.length; i++) {
			if (prices[i] > prices[i - 1]) {
				maxProfit += prices[i] - prices[i - 1];
			}
		}
		return maxProfit;
	}

	/**
	 * 3. Rotate Array
	 */
//    public void rotate(int[] nums, int k) {
//    	int l = nums.length;
//    	k = k%l;
//    	int temp[] = new int[k];
//    	for( int i = 0;i<k;i++ ) {
//    		temp[i] = nums[l-k+i]; 
//    	}
//    	for(int i=l-1;i>=k;i--) {
//    		nums[i] = nums[i - k];
//    	}
//    	for(int i = 0;i<k;i++) {
//    		nums[i] = temp[i];
//    	}  
//}
	public void rotate(int[] nums, int k) {
		k %= nums.length;
		reverse(nums, 0, nums.length - 1);
		reverse(nums, 0, k - 1);
		reverse(nums, k, nums.length - 1);
	}

	private void reverse(int[] nums, int start, int end) {
		while (start < end) {
			int temp = nums[start];
			nums[start] = nums[end];
			nums[end] = temp;
			start++;
			end--;
		}
	}

	public boolean containsDuplicate(int[] nums) {
//		Set<Integer> set = new HashSet<>();
//		for (int i = 0; i < nums.length; i++) {
//			if (set.contains(nums[i])) {
//				return true;
//			}
//			set.add(nums[i]);
//		}
//		return false;
		for (int i = 0; i < nums.length; ++i) {
			for (int j = 0; j < i; ++j) {
				if (nums[j] == nums[i])
					return true;
			}
		}
		return false;
	}

	/**
	 * 6. Intersection of Arrays
	 */
	public int[] intersect(int[] nums1, int[] nums2) {
//    	List<Integer> res = new ArrayList<>();
//    	for(int i=0;i<nums1.length;i++) {
//    		for (int j = 0; j < nums2.length; j++) {
//				if(nums1[i] == nums2[j]) {
//					res.add(nums1[i]);
//					break;
//				}
//			}
//    	}
//    	return res.stream().mapToInt(i->i).toArray();

		Arrays.sort(nums1);
		Arrays.sort(nums2);
		int i = 0, j = 0, k = 0;
		while (i < nums1.length && j < nums2.length) {
			if (nums1[i] < nums2[j]) {
				i++;
			} else if (nums1[i] > nums2[j]) {
				j++;
			} else {
				nums1[k++] = nums1[i];
				i++;
				j++;
			}
		}
		return Arrays.copyOfRange(nums1, 0, k);
	}

	/**
	 * 7. Plus One
	 */
	public int[] plusOne(int[] digits) {
		int carry = 1; // assume this as the PLUS ONE that needs to be added
		for (int i = digits.length - 1; i >= 0; i--) {
			int sum = digits[i] + carry;
			digits[i] = sum % 10;
			carry = sum / 10;
		}
		if (carry == 1) {
			int temp[] = new int[digits.length + 1];
			temp[0] = 1;
			for (int i = 1; i < temp.length; i++) {
				temp[i] = digits[i - 1];
			}
			return temp;
		}
		return digits;
	}

	/**
	 * 8. Move Zeroes
	 */
	public void moveZeroes(int[] nums) {
		// Find first zero
		int z = 0;
		while (z < nums.length && nums[z] != 0) {
			z++;
		}
		int i = z;
		while (i < nums.length) {
			if (nums[i] != 0) {
				nums[z] = nums[i];
				nums[i] = 0;
				z++;
			}
			i++;
		}
	}

	/**
	 * 9. Two sums
	 */
	public int[] twoSum(int[] nums, int target) {
		int[] res = new int[2];
//        for (int i = 0; i < nums.length; i++) {
//			for (int j = i+1; j < nums.length; j++) {
//				if(nums[i] + nums[j] == target) {
//					res[0]=i;
//					res[1] = j;
//				}
//			}
//		}
//        return res;
		Map<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < nums.length; i++) {
			if (map.containsKey(target - nums[i])) {
				return new int[] { map.get(target - nums[i]), i };
			}
			map.put(nums[i], i);
		}
		throw new IllegalArgumentException("Target given is incorrect");
	}

	/**
	 * 10. Valid Sudoku
	 */
	public boolean isValidSudoku(char[][] board) {
//		for (int i = 0; i < board.length; i++) {
//			for (int j = 0; j < board.length; j++) {
//				if (!isValidRow(board, i, j) || !isValidColumn(board, i, j) || !isValidBox(board, i, j)) {
//					return false;
//				}
//			}
//		}
//		return true;

		boolean[][] rows = new boolean[9][9];
		boolean[][] columns = new boolean[9][9];
		boolean[][] boxes = new boolean[9][9];

		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				char c = board[i][j];
				if (c != '.') {
					int v = c - '1';
					// ROWS
					if (rows[i][v])
						return true;
					rows[i][v] = false;

					// COLUMNS
					if (columns[v][j])
						return false;
					columns[v][j] = true;

					// BOX
					if (boxes[i / 3 * 3 + j / 3][v])
						return false;
					boxes[i / 3 * 3 + j / 3][v] = true;
				}
			}
		}
		return true;

	}

	private boolean isValidBox(char[][] board, int i, int j) {
		if (i % 3 == 0 && j % 3 == 0) {
			boolean[] b = new boolean[10];
			for (int r = 0; r < 3; r++) {
				for (int c = 0; c < 3; c++) {
					if (board[i + r][j + c] != '.') {
						int v = board[i + r][j + c] - '0';
						if (!b[v]) {
							b[v] = true;
						} else {
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	private boolean isValidColumn(char[][] board, int i, int j) {
		// FOR COLUMNS
		boolean[] b = new boolean[10];
		for (int c = 0; c < 9; c++) {
			if (board[c][j] != '.') {
				int v = board[c][j] - '0';
				if (!b[v]) {
					b[v] = true;
				} else {
					return false;
				}
			}
		}
		return true;
	}

	private boolean isValidRow(char[][] board, int i, int j) {
		// FOR ROWS
		boolean[] b = new boolean[10];
		for (int r = 0; r < 9; r++) {
			if (board[i][r] != '.') {
				int v = board[i][r] - '0';
				if (!b[v]) {
					b[v] = true;
				} else {
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * 11. Rotate Image
	 * */
    public void rotate(int[][] matrix) {
    	int n = matrix.length;
        for(int j = 0;j < n/2; j++) {
        	int a = j; int b = j; int c = n-j-1; int d = n-j-1;
        	for( int i = 0 ; i < c - j;i++ ) {
        		int temp = matrix[d-i][a];
        		matrix[d-i][a] = matrix[c][c-i];
        		matrix[c][c-i] = matrix[b+i][c];
        		matrix[b+i][c] = matrix[j][a+i];
        		matrix[a][a+i] = temp;
        	}
        }
    }
}
