package com.practice.leetcode.array;

import java.util.Scanner;

public class ReverseArray {
//-2147483648
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			int N = sc.nextInt();
			long s = 0;
			while (N != 0) {
				s = s * 10 + N % 10;
				N /= 10;
			}
			System.out.println(s);
		}
	}
}
