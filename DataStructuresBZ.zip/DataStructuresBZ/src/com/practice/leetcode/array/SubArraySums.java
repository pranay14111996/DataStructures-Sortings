package com.practice.leetcode.array;

import java.util.Arrays;
import java.util.HashMap;

public class SubArraySums {
	public static void main(String[] args) {
		SubArraySums sas = new SubArraySums();
		// int[] nums = { 23, 2, 6, 4, 7 };
		int[] nums = { 9,6,6 };
		System.out.println(sas.checkSubarraySum(nums, 1));
	}

	public boolean checkSubarraySum(int[] nums, int k) {
		if (nums.length > 1) {
			int[] sums = new int[nums.length];
			HashMap<Integer, Integer> map = new HashMap<>();
			if (k == 0) {
				for (int i = 0; i < nums.length; i++) {
					sums[i] = (i > 0) ? sums[i - 1] + nums[i] : nums[i];
					
				}
			} else {
				for (int i = 0; i < nums.length; i++) {
					sums[i] = (i > 0) ? sums[i - 1] + nums[i] : nums[i];
					int mod = sums[i] % k;
					if (map.containsKey(mod)) {
						return true;
					} else {
						map.put(mod, i);
					}
				}
			}
		}
		return false;
	}
	
	
}
