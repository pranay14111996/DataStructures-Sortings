package com.practice.day3;

import java.util.Scanner;

public class UniquePaths {
	long countPaths(int r, int c) {
		if(r==0|| c==0)
	        return 0;
		long[][] dp= new long[r][c];
		for (int i = dp.length - 1; i > -1; i--) {
			for (int j = 0; j < dp[0].length; j++) {
				if (j == 0)
					dp[i][j] = 1;
				else if (i == dp.length - 1)
					dp[i][j] = 1;
				else {
					dp[i][j] = dp[i][j - 1] + dp[i + 1][j];
				}
			}
		}
		return dp[0][c - 1];
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		UniquePaths obj = new UniquePaths();
		while (t-- != 0) {
			int r = sc.nextInt();
			int c = sc.nextInt();
			System.out.printf("%d%n", obj.countPaths(r, c));
		}
		sc.close();
	}
}
