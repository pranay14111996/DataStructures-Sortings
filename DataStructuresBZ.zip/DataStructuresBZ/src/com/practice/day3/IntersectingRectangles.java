package com.practice.day3;

import java.util.Scanner;

class Rectangles {
	int tlX, tlY;
	int brX, brY;

	public Rectangles(int tlX, int tlY, int brX, int brY) {
		super();
		this.tlX = tlX;
		this.tlY = tlY;
		this.brX = brX;
		this.brY = brY;
	}

}

/**
 * Two rectangles do not overlap if one of the following conditions is true. 1)
 * One rectangle is above top edge of other rectangle. 2) One rectangle is on
 * left side of left edge of other rectangle.
 */
public class IntersectingRectangles {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int t = sc.nextInt();
		while (t-- > 0) {
			Rectangles r1 = new Rectangles(sc.nextInt(), sc.nextInt(), sc.nextInt(), sc.nextInt());
			Rectangles r2 = new Rectangles(sc.nextInt(), sc.nextInt(), sc.nextInt(), sc.nextInt());
			System.out.println(new IntersectingRectangles().intersectingRectangles(r1, r2));
		}
//		Rectangles r1 = new Rectangles(0,3,3,0);	Rectangles r2 = new Rectangles(1,2,2,1);
//		System.out.println(new IntersectingRectangles().intersectingRectangles(r1, r2));
	}

	boolean intersectingRectangles(Rectangles r1, Rectangles r2) {

		// 1
		if (r2.brY > r1.tlY || r1.brY > r2.tlY)
			return false;
		// 2
		if (r2.brX < r1.tlX || r1.brX < r2.tlX)
			return false;
		return true;
	}
}
