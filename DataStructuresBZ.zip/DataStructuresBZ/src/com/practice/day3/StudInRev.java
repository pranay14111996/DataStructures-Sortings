package com.practice.day3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class Student{
	String name;
	int age;
	char gender;
	public Student(String name, int age, char gender) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return name + " " + age + " " + gender;
	}
	
}
/*
6
SAGAR 21 M
NISHA 19 f
KUNAL 23 m
RAJAT 20 m
SONAM 100 F
SPOMK 120 F

 * */
public class StudInRev {
	
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int t = sc.nextInt();sc.nextLine();
		List<Student> list = new ArrayList<>();
		while(t-->0) {
			String[] s = sc.nextLine().split(" ");
			//Reverse of a num
			int age = reverse(Integer.parseInt(s[1]));
			
			//Gender
			char gender = getGender(s[2].charAt(0));
			
			Student stud = new Student(s[0].trim(),age,gender);
			list.add(stud);
		}
		Collections.reverse(list);
		int i=0;
		for(Student student:list) {
			if(i==0 || i%2==0) {
				student.name = student.name.toUpperCase();
			}
			else {
				student.name = student.name.toLowerCase();
			}
			i++;
			System.out.println(student);
		}
		
	}

	private static char getGender(char ch) {
		if(ch>='a' && ch<='z') {
			return (char) ('A'+ch-'a');
		}
		else if(ch>='A' && ch<='Z') {
			return (char) ('a'+ch-'A');	
		}
		return 0;
	}

	private static int reverse(int n) {
		int res = 0;
		while(n!=0) {
			res = res*10 + n%10;
			n = n/10;
		}
		return res;
	}
}
