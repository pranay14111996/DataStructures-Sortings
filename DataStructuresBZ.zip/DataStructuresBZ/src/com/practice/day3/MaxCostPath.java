package com.practice.day3;

public class MaxCostPath {
	public static void main(String[] args) {
		int a[][] = { {1,2,3},{4,9,6},{7,8,9} };
		System.out.println(new MaxCostPath().maxPathCost(a));
	}

	int maxPathCost(int a[][]) {
		int dp[][] = new int[a.length+1][a[0].length+1];
		for(int i=1;i<a.length+1;i++) {
			for (int j = 1; j < a[0].length+1; j++) {
				int curr = a[i-1][j-1];
				if( i == 1 )
					dp[i][j] = dp[i][j-1] + dp[i][j] + curr;
				else if(j == 1) {
					dp[i][j] = dp[i-1][j] + dp[i][j]+ curr;
				}
				else {
					dp[i][j] = curr + Math.max(dp[i-1][j], dp[i][j-1]);
				}
			}
		}
		return dp[a.length][a[0].length];
	}
}
