package com.practice.day3;

import java.util.Arrays;
import java.util.Comparator;

public class ColumnSort {
	void columnSort(int a[][], int  colNum)
	  {
		if(colNum >-1 && colNum < a[0].length) {
			Arrays.sort(a,new Comparator<int[]>() {

			@Override
			public int compare(int[] o1, int[] o2) {
				return o1[colNum] - o2[colNum];
			}
			
			});
		}
	  }
	public static void main(String[] args) {
		ColumnSort cs = new ColumnSort();
		int a[][] = {{1,18,3,4},{12,16,11,14},{17,14,15,2},{11,2,7,6}};
		new ColumnSort().columnSort(a, 1);
		System.out.println( Arrays.deepToString(a) );
		
	}
}
