package com.practice.day3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class ABCWasnotABC {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		int t = sc.nextInt();sc.nextLine();
		while(t-->0) {
			char[] alpha = sc.nextLine().toCharArray();
			int[] priority = new int[26];
			for(int i=0;i<alpha.length;i++) {
				priority[alpha[i] - 'A'] = i;
			}
			int q = sc.nextInt();sc.nextLine();
			while(q-->0) {
				char[] qCh = sc.nextLine().toCharArray();
				List<Character> res = new ArrayList<>();
				for(char ch:qCh) {
					res.add(ch);
				}
				Collections.sort(res, new Comparator<Character>() {

					@Override
					public int compare(Character o1, Character o2) {
						
						return priority[o1.charValue()-'A'] - priority[o2.charValue()-'A'];
					}
				});
				res.stream().forEach(System.out::print);
				System.out.print(" ");
			}
			
			System.out.println();
		}
	}
}
