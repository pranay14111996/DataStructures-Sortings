package com.practice.day0;

import java.util.Arrays;
import java.util.Scanner;

public class BuiltIn {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		while (t-- != 0) {
			int n = sc.nextInt();
			int q = sc.nextInt();

			// Note: Array is instantiated, after knowing n only.
			int a[] = new int[n];

			for (int ai = 0; ai < n; ai++)
				a[ai] = sc.nextInt();

			// TODO: Sort the array using built-in function Arrays.sort
			Arrays.sort(a);

			// TODO: Read Q queries and print answer for every query
			while (q-- != 0) {
				int qi = sc.nextInt();
				if (qi >= a.length || qi < 0)
					System.out.print(-1 + " ");
				else
					System.out.print(a[qi] + " ");
			}
			System.out.println();
		}
	}
}
