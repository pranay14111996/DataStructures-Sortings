package com.practice.day0;

import java.util.Scanner;

public class ChoosyPrint {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		sc.nextLine(); // This is to discard newline character after t

		ChoosyPrint cp = new ChoosyPrint();
		while (t-- != 0) {
			String s = sc.nextLine();
			cp.choosyPrint(s);
			System.out.println();
		}
	}

	void choosyPrint(String s) {
		for (int i = 0; i < s.length(); i++) {
			char ch = toLower(s.charAt(i));

			if (!isVowelOrY(ch)) {
				if(consonant(ch))
					System.out.print("*");
				System.out.print(ch);
			}
		}
	}

	private boolean consonant(char ch) {
		return ch >= 'a' && ch <= 'z' && !isVowelOrY(ch);
	}

	private char toLower(char ch) {
		if (ch >= 'A' && ch <= 'Z') {
			return (char) ('a' + ch - 'A');
		}
		return ch;
	}

	private boolean isVowelOrY(char ch) {
		return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'y';
	}

}
