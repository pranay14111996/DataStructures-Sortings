package com.practice.day0;

import java.util.Arrays;

public class MaxSumRootToLeaf {

	int maxSumRootToLeaf(BTNode root) {
		if (root == null)
			return 0;
		int ls = maxSumRootToLeaf(root.left);
		int rs = maxSumRootToLeaf(root.right);
		return root.data + (ls > rs ? ls : rs);
	}

	boolean hasPathSumRootToLeaf(BTNode root, int s) {
		if (root == null) {
			return false;
		}
		if (root.left == null && root.right == null) {
			return root.data == s;
		}
		return hasPathSumRootToLeaf(root.left, s - root.data) || hasPathSumRootToLeaf(root.right, s - root.data);
	}

	boolean isSubSequence(char sub[], char sup[]) {
		return isSubSeqHelper(sub, sup, 0, 0);
	}

	private boolean isSubSeqHelper(char[] sub, char[] sup, int i, int j) {
		if (i == sub.length) {
			return true;
		}
		while (j < sup.length && sub[i] != sup[j]) {
			j++;
		}
		if (j == sup.length) {
			return false;
		}
		return isSubSeqHelper(sub, sup, ++i, ++j);
	}

	int hasSubsetWithSumContigous(int arr[], int S) {

		return hasSubSetWithSumHelperContigous(arr, S, arr.length);
	}
	
	private int hasSubSetWithSumHelperContigous(int[] arr, int s, int length) {
		int count = 0;
		
		return count;
	}

	boolean hasSubsetWithSum(int arr[], int S) {

		return hasSubSetWithSumHelper(arr, S, arr.length);
	}

	private boolean hasSubSetWithSumHelper(int[] arr, int S, int l) {
		if (l == 0) {
			return S == 0;
		}
		l = l - 1;
		return hasSubSetWithSumHelper(arr, S - arr[l], l) || hasSubSetWithSumHelper(arr, S, l);
	}

	static int dp[][];
	int arr[];

	boolean hasSubsetWithSumDP(int arr[], int S) {
		dp = new int[arr.length+1][S+1];
		for (int i = 0; i <= arr.length; i++) {
			Arrays.fill(dp[i], -1);
		}
		this.arr = arr;
		return hasSubSetWithSumHelperDP(arr.length, S);
	}

	private boolean hasSubSetWithSumHelperDP(int length, int s) {
		if (s == 0)
			return true;
		if (length == 0 || s<0)
			return false;
		if (dp[length][s] == -1) {
			dp[length][s] = (hasSubSetWithSumHelperDP(length - 1, s - arr[length - 1])
					|| hasSubSetWithSumHelperDP(length - 1, s)) ?1:0;
		}
		return dp[length][s] == 1;

	}

	boolean hasEqualSumPartitions(int arr[]) {
		int S = 0;
		for (int i = 0; i < arr.length; i++) {
			S += arr[i];
		}
		if ((S & 1) == 1)
			return false;
		return hasSubSetWithSumHelper(arr, S >> 1, arr.length);
	}

	public static void main(String[] args) {
		BTNode root = new BTNode(1);
		root.left = new BTNode(7);
		root.right = new BTNode(2);
		root.right.right = new BTNode(4);
		root.right.right.left = new BTNode(6);
		root.right.right.right = new BTNode(5);

//		BTNode root = new BTNode(-1);
//		root.left = new BTNode(7);
//		root.right = new BTNode(1);
//		root.right.right =  new BTNode(-4);
//		root.right.right.left = new BTNode(-6);
//		root.right.right.right = new BTNode(5);
		int[] arr = { 1, 2, 3, 4 };
		System.out.println(new MaxSumRootToLeaf().maxSumRootToLeaf(root));

		System.out.println(new MaxSumRootToLeaf().hasPathSumRootToLeaf(root, 13));

		System.out.println(new MaxSumRootToLeaf().isSubSequence("ppa".toCharArray(), "apple".toCharArray()));

		System.out.println("hasSubsetWithSum::" + new MaxSumRootToLeaf().hasSubsetWithSum(arr, 10));
		
		System.out.println("hasSubsetWithSum DP::" + new MaxSumRootToLeaf().hasSubsetWithSumDP(arr, 10));

		System.out.println("hasEqualSumPartitions::" + new MaxSumRootToLeaf().hasEqualSumPartitions(arr));
	}
}

class BTNode {
	int data;
	BTNode left, right;

	BTNode(int d) {
		data = d;
		left = right = null;
	}
}
