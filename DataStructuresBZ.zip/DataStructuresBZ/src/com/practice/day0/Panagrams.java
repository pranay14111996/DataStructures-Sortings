package com.practice.day0;

import java.util.Scanner;

public class Panagrams {
	static Scanner sc = new Scanner(System.in);
	static boolean visited[] = new boolean[26];
	static int totalWeight = 0;
	static int weights[] = new int[26];
	public static void main(String[] args) {
		int T = sc.nextInt();
		while (T-- > 0) {
			visited = new boolean[26];
			weights = new int[26];
			totalWeight = 0;
			int i = -1;
			while (i++ < 25) {
				weights[i] = sc.nextInt();
				totalWeight +=weights[i];
			}
			sc.nextLine();
			String s = sc.nextLine();
			System.out.println(getWeights(s.toCharArray()));
		}
	}

	private static int getWeights(char[] chArr) {
		for (int i = 0; i < chArr.length; i++) {
			if(!visited[chArr[i] - 'a']) {
				visited[chArr[i] - 'a'] = true;
				totalWeight-= weights[chArr[i] - 'a'];
			}	
			
		}
		return totalWeight;
	}
}
