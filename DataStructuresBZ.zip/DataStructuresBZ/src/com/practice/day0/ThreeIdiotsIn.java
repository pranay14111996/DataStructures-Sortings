package com.practice.day0;

public class ThreeIdiotsIn {
	public static void main(String[] args) {
		int arr[] = {0, 2, 3, 4, 1};
		System.out.println(areThreeIdiotsIn(arr));
	}
	static boolean areThreeIdiotsIn(int arr[]) {
		int l = arr.length;
	   if( l < 3) {
		   return false;
	   } 
	   for(int i = 2;i< l;i++) {
		   if(arr[i] - arr[i-1] == 1 && arr[i-1] - arr[i-2] == 1) {
			   return true;
		   }
	   }
	   return false;
	}
}
