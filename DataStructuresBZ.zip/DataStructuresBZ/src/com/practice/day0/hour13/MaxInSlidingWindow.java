package com.practice.day0.hour13;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Scanner;

public class MaxInSlidingWindow {
	static Scanner sc = new Scanner(System.in);
//	1
//	6 3 
//	2 5 4 3 1 7
	public static void main(String[] args) {
		int t = sc.nextInt();
		while (t-- > 0) {
			int N = sc.nextInt();
			int K = sc.nextInt();
			int[] arr = new int[N];
			for (int i = 0; i < arr.length; i++) {
				arr[i] = sc.nextInt();
			}

			printMaxInSlidingWindow(arr, K);
		}
	}

	private static void printMaxInSlidingWindow(int[] arr, int k) {
		Deque<Integer> queue = new LinkedList<>();
		for (int i = 0; i < arr.length; i++) {
			if (!queue.isEmpty()) {
				while (queue.peekFirst() < i - k) {
					queue.removeFirst();
				}
				if (arr[i] >= arr[queue.peek()]) {
					queue.clear();
				} else {
					while (arr[i] >= arr[queue.peekLast()]) {
						queue.removeLast();
					}
				}
			}
			queue.add(i);
			if (i >= k-1)
				System.out.print(arr[queue.peekFirst()]);
		}
	}
}
