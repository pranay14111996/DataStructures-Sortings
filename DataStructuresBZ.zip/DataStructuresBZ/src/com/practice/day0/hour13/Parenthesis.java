package com.practice.day0.hour13;

import java.util.Stack;

public class Parenthesis {
	public static void main(String[] args) {
		
	}
	boolean validateParenthesis(char s[]) {
	    Stack<Character>  stk = new Stack<>();
	    for(char c : s) {
	    	if(isOpen(c)) {
	    		stk.push(c);
	    	}
	    	else if (isClose(c)) {
	    		if(stk.isEmpty()) {
	    			return false;
	    		}
	    		char pop = stk.pop();
	    		if( !((pop == '(' && c == ')') || (pop == '[' && c == ']') || (pop == '{' && c == '}'))) {
	    			return false;
	    		} 
	    	}
	    }
	    return stk.isEmpty();
	}
	boolean isOpen(char c) {
		return c == '(' || c == '{' || c == '[';
	}
	boolean isClose(char c) {
		return c == ')' || c == '}' || c == ']';
	}
}
