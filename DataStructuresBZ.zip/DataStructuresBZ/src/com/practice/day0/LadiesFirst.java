package com.practice.day0;

import java.util.Arrays;

public class LadiesFirst {
	static char arr[] = "GGGLGGGG".toCharArray();

	public static void main(String[] args) {
		ladiesFirst(arr);
		System.out.println( Arrays.toString(arr) );

	}

	static void ladiesFirst(char arr[]) {
		int l = 0;
		int g = arr.length - 1;
		while (l < g) {
			if (arr[g] == 'L') {
				while (l < g && arr[l] != 'G') {
					l++;
				}
				char temp = arr[g];
				arr[g] = arr[l];
				arr[l] = temp;
				l++;
			}
			g--;
		}
	}
}
