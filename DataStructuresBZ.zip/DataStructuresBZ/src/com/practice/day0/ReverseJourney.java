package com.practice.day0;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class ReverseJourney {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		ReverseJourney reverseJourney = new ReverseJourney();
		ArrayList<String> path = new ArrayList<String>();
		path.add("DEL");
		path.add("HYD");
		path.add("BLR");

		reverseJourney.printReturnJourneyPath(path);
	}

	void printReturnJourneyPath(ArrayList<String> path) {
		ListIterator<String> listIterator = path.listIterator(path.size());
		
		while(listIterator.hasPrevious()) {
			System.out.print(listIterator.previous());
			if(listIterator.hasPrevious()) {
				System.out.print("->");
			}
		}
	}
}
