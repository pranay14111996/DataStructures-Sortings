package com.practice.day0.hour18;

import java.util.Arrays;

public class BuildMaxHeap {
	void buildMaxHeap(int arr[]) {
		buildMaxHeapHelpr(arr,arr.length);
	}

	private void buildMaxHeapHelpr(int[] arr, int N) {
		for(int i = (N/2)-1;i>-1;i--) {
			maxHeapify(arr, i, N);
		}
	}
	
	void heapsortArray(int arr[]) {
		int N = arr.length;
		while(N > 0) {
			buildMaxHeapHelpr(arr,N);
			swap(arr,N-1,0);
			N--;
		}
	}
	
	private void maxHeapify(int[] arr, int i,int N) {
		int left = 2*i + 1;
		int right = 2*i + 2;
		int maxIdx = i;
		if( left < N && arr[maxIdx] < arr[left] ) {
			maxIdx = left;
		}
		if( right < N && arr[maxIdx] < arr[right] ) {
			maxIdx = right;
		}
		if(maxIdx != i) {
			swap(arr,i,maxIdx);
			maxHeapify(arr,maxIdx,N);				
		}
	}

	private void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	public static void main(String[] args) {
		int arr[] = {20,7,5,10,15,8,6,1,2,8,6};
		new BuildMaxHeap().buildMaxHeap(arr);
		System.out.println(Arrays.toString(arr));
		System.out.println("after Sorting");
		new BuildMaxHeap().heapsortArray(arr);
		System.out.println(Arrays.toString(arr));
	}
}
