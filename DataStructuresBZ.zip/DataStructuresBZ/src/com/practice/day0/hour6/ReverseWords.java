package com.practice.day0.hour6;

import java.util.Arrays;

public class ReverseWords {
	public static void main(String[] args) {
		char arr[] = new String(" a ").toCharArray();
		new ReverseWords().reverseWords(arr);
		System.out.println(Arrays.toString(arr));
	}

	void reverseWords(char arr[]) {
		int i = 0;
		int start = 0;
		while(i<arr.length) {
			while(i<arr.length && arr[i] != ' ' ) {
				i++;
			}
			helper(arr,start,i-1);
			while(i<arr.length && arr[i]==' ') {
				i++;
			}
			start = i;
		}
		helper(arr,0,arr.length-1);
	}
	
	void helper(char[] arr, int s, int e) {
		while(s<=e) {
			char temp = arr[s];
			arr[s] = arr[e];
			arr[e] = temp;
			s++;e--;
		}
	}
}
