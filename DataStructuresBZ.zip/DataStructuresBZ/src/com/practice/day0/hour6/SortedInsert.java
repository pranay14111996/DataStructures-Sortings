package com.practice.day0.hour6;

public class SortedInsert {
	public static void main(String[] args) {
		int a[] = { 1, 3, 3, 9, 12, 15 };
		// 0 1 2 3 4 5 6 7
		System.out.println(new SortedInsert().sortedInsertPosition(a, 2));
	}

	int a[];
	int k;

	private int sortedInsertPosition(int[] a, int k) {
		this.a = a;
		this.k = k;
		return helper(0, a.length - 1);
	}

	private int helper(int b, int e) {
		if (b <= e) {
			int m = (e - b) / 2 + b;
			if (a[m] == k) {
				return m;
			} else if (a[m] < k) {
				return helper(m + 1, e);
			} else if (a[m] > k) {
				return helper(b, m - 1);
			}
		}
		return b;
	}
}
