package com.practice.day0.hour6;

public class FindFreq {
	public static void main(String[] args) {
		int a[] = { 1, 5 };
		// 0 1 2 3 4 5 6 7
		System.out.println(findFreq(a, 1));
	}

	static int a[];
	static int k;

	static int findFreq(int a[], int k) {
		FindFreq.a = a;
		FindFreq.k = k;
		int lIdx = left(0, a.length - 1);
		if (lIdx == -1)
			return 0;
		int rIdx = right(lIdx, a.length - 1);
		return rIdx - lIdx + 1;
	}

	private static int left(int b, int e) {
		if (b <= e) {
			int m = ((e - b) / 2) + b;
			if (a[m] == k && (m == 0 || a[m - 1] < k)) {
				return m;
			} else if (a[m] < k) {
				return left(m + 1, e);
			} else {
				return left(b, m - 1);
			}
		}
		return -1;
	}

	private static int right(int b, int e) {
		if (b <= e) {
			int m = ((e - b) / 2) + b;
			if (a[m] == k && (m == a.length - 1 || a[m + 1] > k)) {
				return m;
			} else if (a[m] > k) {
				return right(b, m - 1);
			} else {
				return right(m + 1, e);
			}
		}
		return -1;
	}
}
