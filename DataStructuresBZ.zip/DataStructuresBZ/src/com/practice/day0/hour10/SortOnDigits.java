package com.practice.day0.hour10;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortOnDigits {
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(12);		list.add(345);		list.add(2);
		list.add(5678);		list.add(13000);	list.add(13000);
		
		new SortOnDigits().sortOnDigits(list);
		System.out.println(list.toString());
	}
	void sortOnDigits(List<Integer> al)
    {
		Collections.sort(al, (a,b)->{
			return (int)Math.log10(a) - (int)Math.log10(b);
		});
    }
}
