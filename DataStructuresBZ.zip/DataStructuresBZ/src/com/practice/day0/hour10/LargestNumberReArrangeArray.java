package com.practice.day0.hour10;

import java.util.Arrays;

public class LargestNumberReArrangeArray {
	public static void main(String[] args) {
//		int arr[] = { 1, 20, 9, 90, 89 };
		int arr[] = {3,30,34,5,9};
//		int arr[] = {888888889,888888887,888888888,9999};
		new LargestNumberReArrangeArray().rearrangeArrayToFormLargestNumber(arr);
//		System.out.println(Arrays.toString(arr));
	}

	void rearrangeArrayToFormLargestNumber(int data[]) {
		Integer[] a = Arrays.stream(data).boxed().toArray(Integer[]::new);
		Arrays.sort(a, (m, n) -> {
			return String.valueOf(n).compareTo(String.valueOf(m));
		});
		for(int i : a) {
			System.out.print(i+", ");
		}
	}
}
