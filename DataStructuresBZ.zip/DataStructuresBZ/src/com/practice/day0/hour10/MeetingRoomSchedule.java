package com.practice.day0.hour10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Request {

	int start;
	int end;

	public Request(int start, int end) {
		this.start = start;
		this.end = end;
	}
	
	public boolean isOutside(Request other) {
		return (this.start >= other.end || this.end <= other.start);
	}
	
	public boolean isInside(Request other) {
		return (this.start >= other.start && this.end <= other.end);
	}

	@Override
	public String toString() {
		return "Request [start=" + start + ", end=" + end + "]";
	}
	
}

public class MeetingRoomSchedule {
	public static void main(String[] args) {
		Request r1 = new Request(1,3);
		Request r2 = new Request(5,7);
		Request r3 = new Request(2,4);
		Request r4 = new Request(8,11);
		Request r5 = new Request(8,10);
		Request r6 = new Request(3,7);
		Request r7 = new Request(10,13);
		
//		Request r1 = new Request(2,5);
//		Request r2 = new Request(1,9);
//		Request r3 = new Request(4,5);
//		Request r4 = new Request(3,4);
//		Request r5 = new Request(7,9);
//		
		List<Request> requests = new ArrayList<>();
		requests.add(r1);requests.add(r2);requests.add(r3);
		requests.add(r4);requests.add(r5);requests.add(r6);requests.add(r7);
		System.out.println(new MeetingRoomSchedule().maxMeetingsPossible(requests));
	}

	int maxMeetingsPossible(List<Request> requestsList) {
		Collections.sort(requestsList, (Comparator<? super Request>) (Request a,Request b)->{
			if(a.start == b.start) {
				return a.end - b.end;
			}
			return a.start - b.start;
			
		});
		if(requestsList.isEmpty()) {
			return 0;
		}
		Request init = requestsList.get(0);
		int count = 1;
		for(Request req:requestsList) {
			if(req.isOutside(init)) {
				init = req;
				count++;
			}
			else if (req.isInside(init)) {
				init = req;
			}
		}
		return count;
	}

}
