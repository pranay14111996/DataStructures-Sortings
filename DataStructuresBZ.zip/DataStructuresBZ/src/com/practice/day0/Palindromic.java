package com.practice.day0;

public class Palindromic {
	/**
	 * Precedence order ! greaterThan && greaterThan ||  
	 * */
	public static void main(String[] args) {
		int arr[] = {10,20,20,10};
		Palindromic p = new Palindromic();
		//System.out.println( p.isPalindrome(arr) );
		
//		boolean result = p.m1() || p.m2() && p.m3();
//      boolean result = p.m1() && p.m2() || p.m3();
//		boolean result = false || true && false;
//		boolean result = true || false && false;
		boolean result = true && false || true;
		
		System.out.println(result);
	}
	
	boolean isPalindrome(int[] arr) {
		return isPalindromeHelper(0,arr.length-1,arr);
	}
	boolean isPalindromeHelper(int s, int e, int[] arr) {
		return s>e || arr[s]==arr[e] && isPalindromeHelper(++s,--e,arr);
	}
	
	boolean m1() {
		System.out.println(" m1() ");
		return true;
	}
	boolean m2() {
		System.out.println(" m2() ");
		return true;
	}
	boolean m3() {
		System.out.println(" m3() ");
		return true;
	}
	boolean m4() {
		System.out.println(" m4() ");
		return true;
	}
}
