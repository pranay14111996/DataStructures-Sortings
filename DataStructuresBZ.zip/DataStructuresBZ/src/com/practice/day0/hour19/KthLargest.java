package com.practice.day0.hour19;

import java.util.PriorityQueue;

public class KthLargest {
	public static void main(String[] args) {
		int arr[] = { 30, 20, 10, 40, 50 };
		System.out.println( new KthLargest().getKthLargestElement(arr, 3) );
	}
	
	int getKthLargestElement2(int a[], int k) {
	     if(k>a.length || k<=0){
	      	return -1;
	      }
	   	 PriorityQueue<Integer> pq = new PriorityQueue<>(k);
	   	 for(int i = 0;i<a.length;i++){
	      	if(i<k){
	         	pq.add(a[i]);
	         }
	        	else if( pq.peek() < a[i] ){
	         	pq.poll();
	           	pq.add(a[i]);
	         }
	      }
	   		return pq.peek();
	   	 
	}
	

	int getKthLargestElement(int a[], int k) {
		int arr[] = new int[k];
		for(int i=0;i<k;i++) {
			arr[i] = a[i];
		}
		buildMinHeap(arr,k);
		for(int i = k;i<a.length;i++) {
			if(arr[0] < a[i]) {
				removeMin(arr, k);
				add(arr, k, a[i]);
			}
		}
		return a[0];
	}
	
	void buildMinHeap(int[] arr,int N) {
		for(int i = N/2 -1;i>-1;i--) {
			minHeapify(arr,i,N);
		}
	}

	private void minHeapify(int[] arr, int i, int N) {
		int minIdx = i;
		int left = 2*i + 1;
		int right = 2*i + 2;
		
		if(left < N && arr[left] < arr[minIdx] ) {
			minIdx = left;
		}
		if(right < N && arr[right] < arr[minIdx] ) {
			minIdx = right;
		}
		if(minIdx != i) {
			swap(arr,i,minIdx);
			minHeapify(arr,minIdx,N);
		}
	}
	
	private int removeMin(int arr[], int N) {
		swap(arr,0,N-1);
		buildMinHeap(arr, N-1);
		return arr[N-1];
	}
	private void add(int arr[], int N, int data) {
		arr[N-1] = data;
		buildMinHeap(arr, N);
	}

	private void swap(int[] arr, int i, int minIdx) {
		int temp = arr[i];
		arr[i] = arr[minIdx];
		arr[minIdx] = temp;
	}
}
