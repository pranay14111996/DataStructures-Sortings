package com.practice.day0.hour19;

import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Scanner;

public class RunningMedians {
	//Assume left stores the elements less equals than median, right stores greater equals than median
	static PriorityQueue<Integer> max;
	static PriorityQueue<Integer> min;
	static double median = Integer.MIN_VALUE;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(sc.hasNext()) {
			int t = sc.nextInt();
			while(t-- > 0) {
				max = new PriorityQueue<>(Collections.reverseOrder());
				min = new PriorityQueue<>();
				int n = sc.nextInt();
				while(n -- > 0) {
					System.out.print( getMedian(sc.nextInt()) +"0 ");
				}
				System.out.println();
			}
		}
	}
	private static double getMedian(int n) {
		// if n is greater than median, n should go in right bucket-> remove the element from right bucket(min heap) and place in left bucket(max heap) and place n in right
		// if n is less than median, n should go in left bucket -> remove the element from left bucket(max heap) and place in right bucket(min heap) and place n in left
		// if n is equal to median, 
		if( max.size() == min.size() ) {
			if( n > median ) {
				min.add(n);
				median = min.peek();
			}
			else {
				max.add(n);
				median = max.peek();
			}
			
		}
		else if (max.size() > min.size()) {
			if( n < median ) {
				min.add(max.remove());
				max.add(n);
			}
			else {
				min.add(n);
			}
			median = (double)(min.peek() + max.peek()) / 2;
		}
		else{
			if( n > median ) {
				max.add(min.remove());
				min.add(n);
			}
			else {
				max.add(n);
			}
			median = (double)(min.peek() + max.peek()) / 2;
		}
		return median;
	}
	
}
