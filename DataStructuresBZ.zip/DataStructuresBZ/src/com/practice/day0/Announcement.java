package com.practice.day0;

import java.util.Scanner;

/*
 * Given a number N>=0 (integer), Print its digits in words so that auto-announcement system of railway can pick the words and speak.
 * */
public class Announcement {

		String[] numbers = {"ZERO ","ONE ","TWO ","THREE ","FOUR ","FIVE ","SIX ","SEVEN ","EIGHT ","NINE "};
	    void trainNumberToWords(int N)
	    {
	     
	         StringBuilder announcement = approach1(N);
	         System.out.println("APPROACH 1");
	         System.out.println(announcement.toString());
	         System.out.println("APPROACH 2");
	         System.out.println(approach2(N));
	         
	    }
		private StringBuilder approach1(int N) {
			int numberOfDigits = (N!=0)?(int)Math.log10(N) + 1:1;
	         
	         StringBuilder announcement = new StringBuilder(); 
	         while(N > 0) {
	        	 announcement.append(numbers[(int) (N/Math.pow(10, --numberOfDigits))]);
	        	 N = (int) (N%Math.pow(10, numberOfDigits));
	         }
	         while(numberOfDigits-->0) {
	        	 announcement.append(numbers[0]);
	         }
			return announcement;
		}  
		
		private String approach2(int N) {
	    	if(N < 10)
	            return numbers[N];
	        	return approach2(N/10)+""+numbers[N%10];
		}
		static Scanner sc = new Scanner(System.in);
		public static void main(String[] args)
		{
			Announcement announcement = new Announcement();
	      	while(sc.hasNext()){
	          int N = sc.nextInt();
	          announcement.trainNumberToWords(N);
	          System.out.println();
	        }
		}
}
