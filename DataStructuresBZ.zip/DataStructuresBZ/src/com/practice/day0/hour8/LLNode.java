package com.practice.day0.hour8;

public class LLNode {
	int data;
	LLNode next;

	LLNode(int d) {
		data = d;
		next = null;
	}
}
