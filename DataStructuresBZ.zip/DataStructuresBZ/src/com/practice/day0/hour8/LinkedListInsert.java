package com.practice.day0.hour8;

import java.util.Scanner;

class LinkedListFunctions {
	void printList(LLNode head) {
		LLNode temp = head;
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.next;
		}
		System.out.println();
	}

	LLNode insertInBeginning(LLNode head, int data) {

		LLNode node = new LLNode(data);
		if (head == null) {
			return node;
		}
		node.next = head;
		return node;

	}

	LLNode InsertAtEnd(LLNode head, int data) {
		LLNode node = new LLNode(data);
		if (head == null) {
			return node;
		}
		LLNode temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}
		temp.next = node;
		return head;

	}
}

public class LinkedListInsert {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		LinkedListFunctions llf = new LinkedListFunctions();
		while (t-- != 0) {
			LLNode head = null;
			int n = sc.nextInt();
			while (n-- != 0) {
				head = llf.insertInBeginning(head, sc.nextInt());
			}
			llf.printList(head);
		}
	}
}