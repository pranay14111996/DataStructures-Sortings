package com.practice.day0.hour8;

import java.util.Scanner;

public class LinkedListDelete {
	LLNode deleteNode(LLNode h, int data)
	{
		if(h==null) {
			return null;
		}
		if(h.data == data) {
			return h.next;
		}
		LLNode temp = h;
		while( temp.next != null && temp.next.data != data) {
			temp = temp.next;
		}
		temp.next = temp.next ==null?null:temp.next.next; 
		return h;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		LinkedListFunctions llf = new LinkedListFunctions();
		while (t-- != 0) {
			LLNode head = null;
			int n = sc.nextInt();
			while (n-- != 0) {
				head = llf.insertInBeginning(head, sc.nextInt());
			}
			llf.printList(head);
		}
	}

}
