package com.practice.day0.hour8;

import java.util.Scanner;

public class ReverseLinkedList {

	LLNode reverseList(LLNode head) {
		if(head == null || head.next == null)
			return head;
		LLNode p = null;LLNode c = head;LLNode n = head.next;
		while(c !=null) {
			c.next = p;
			p = c;
			c= n;
			n = n == null?null:n.next;
		}
		return p;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		LinkedListFunctions llf = new LinkedListFunctions();
		while (t-- != 0) {
			LLNode head = null;
			int n = sc.nextInt();
			while (n-- != 0) {
				head = llf.insertInBeginning(head, sc.nextInt());
			}
			llf.printList(head);
			ReverseLinkedList rll = new ReverseLinkedList();
			head = rll.reverseList(head);
			llf.printList(head);
		}
	}

}
