package com.practice.day0.hour11;

import java.util.Scanner;
/**
 * 
 *  nCr  = n-1Cr + n-1Cr-1
 *	nC0  = 1
 *	nCn  = 1
 * */
public class BinomialCoef {
	static Scanner sc = new Scanner(System.in);
	static int[][] dp;
	int mod = (int) (Math.pow(10, 9)+7);
	public static void main(String[] args) {
		int t = sc.nextInt();
		while (t-- > 0) {
			int n = sc.nextInt();
			int r = sc.nextInt();
			dp = new int[n+1][r+1];
			System.out.println( new BinomialCoef().ncr(n,r) );
		}
	}
	private int ncr(int n, int r) {
		if(n<r) {
			return -1;
		}
		if(r==0 || r == n)
			return 1;
		if(dp[n][r] == 0) {
			dp[n][r] = (ncr(n-1,r-1)%mod +ncr(n-1,r)%mod)%mod;
		}
		return dp[n][r];
	}
}
