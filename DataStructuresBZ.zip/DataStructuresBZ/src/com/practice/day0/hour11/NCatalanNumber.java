package com.practice.day0.hour11;

import java.util.Scanner;

/**
 * This is how we calculate Nth Catalan Number: catalan(n) = cat(n-1)*cat(0) +
 * cat(n-2)*cat(1)+.......+ cat(1)*cat(n-2) + cat(0)*cat(n-1)
 * 
 * Recursively defining catalan(n) = SUM OF ALL (cat(i) * cat(n-i-1)) where i
 * changes from 0 to n-1 catalan(0) = 1 catalan(1) = 1
 */
public class NCatalanNumber {
	static Scanner sc = new Scanner(System.in);
	static int dp[];
	public static void main(String[] args) {
		int t = sc.nextInt();
		while(t-->0) {
			int n = sc.nextInt();
			dp = new int[n+1];
			System.out.println(new NCatalanNumber().catalan(n));
		}
	}
	private int catalan(int n) {
		for(int i=0;i<=n;i++) {
			if(i==0||i==1) {
				dp[i] = 1;
				continue ;
			}
			int sum = 0;
			for(int j=0;j<i;j++) {
				sum += dp[j]*dp[i-j-1];
			}
			dp[i]=sum;
		}
		return dp[n];
	}
}
