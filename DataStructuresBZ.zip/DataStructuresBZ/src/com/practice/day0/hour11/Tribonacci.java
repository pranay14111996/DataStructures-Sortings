package com.practice.day0.hour11;

import java.util.Scanner;

public class Tribonacci {
	static Scanner sc = new Scanner(System.in);
	static int[] dp;
	int mod = (int) (Math.pow(10, 9)+7);
	public static void main(String[] args) {
		int t = sc.nextInt();
		while (t-- > 0) {
			int n = sc.nextInt();
			dp = new int[n+3];
			System.out.println( new Tribonacci().tribonacci(n) );
		}
	}
	private int tribonacci(int n) {
		dp[0] = 0;dp[1] = 0;dp[2] = 1;
		for(int i = 3 ;i<n;i++) {
			dp[i] = ((dp[i-2]%mod+dp[i-1]%mod)%mod+dp[i])%mod;
		}
		return dp[n];
	}
}
