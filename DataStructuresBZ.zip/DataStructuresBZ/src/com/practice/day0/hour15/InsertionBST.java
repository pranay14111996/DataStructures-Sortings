package com.practice.day0.hour15;

class BSTNode {

	int data;
	BSTNode left, right;

	public BSTNode(int data) {
		this.data = data;
		this.left = this.right = null;
	}
}

class BTNode {
	int data;
	BTNode left, right;

	BTNode(int d) {
		data = d;
		left = right = null;
	}
}

public class InsertionBST {
	public static void main(String[] args) {
		InsertionBST insertionBST = new InsertionBST();
		BSTNode root = new BSTNode(5);
		insertionBST.insertBSTNode(root, 2);
		insertionBST.insertBSTNode(root, 4);
		insertionBST.insertBSTNode(root, 6);
		insertionBST.insertBSTNode(root, 7);
		insertionBST.insertBSTNode(root, 5);

		insertionBST.printInOrder(root);
		System.out.println("\n" + (insertionBST.searchBSTNode(root, 6) != null));
	}

	public BSTNode insertBSTNode(BSTNode root, int data) {
		if (root == null)
			return new BSTNode(data);
		if (root.data > data) {
			root.left = insertBSTNode(root.left, data);
		} else {
			root.right = insertBSTNode(root.right, data);
		}
		return root;
	}

	public BSTNode searchBSTNode(BSTNode root, int d) {
		if (root == null) {
			return null;
		}
		if (root.data == d) {
			return root;
		}
		if (root.data > d) {
			return searchBSTNode(root.left, d);
		} else {
			return searchBSTNode(root.right, d);
		}
	}

	int heightOfTree(BTNode root) {
		if (root == null)
			return 0;
		else
			return 1 + Math.max(heightOfTree(root.left), heightOfTree(root.right));
	}

	int countLeafNodes(BTNode root) {
		if (root == null)
			return 0;
		if (root.left == null && root.right == null) {
			return 1;
		}
		return countLeafNodes(root.left) + countLeafNodes(root.right);
	}

	int heightOfTree(BSTNode root) {
		if (root == null)
			return 0;
		else
			return 1 + Math.max(heightOfTree(root.left), heightOfTree(root.right));
	}
	
	int getBF(BSTNode node) {
		if(node == null)
			return 0;
		return heightOfTree(node.left) - heightOfTree(node.right); 
	}
	

	public void printInOrder(BSTNode root) {
		if (root == null)
			return;
		printInOrder(root.left);
		System.out.print(root.data + " ");
		printInOrder(root.right);
	}
}
