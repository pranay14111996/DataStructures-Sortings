package com.practice.day0.hour7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrintDiagonalMatrix {
	static void printDiagonally(List< List<Integer> > mat){
		int r = mat.size();
		int c = mat.get(0).size();
		for(int k=0;k<r;k++) {
			int i = k;
			int j = 0;
			while(i>=0 && j < c) {
				System.out.print(mat.get(i).get(j)+" ");
				j++;i--;
			}
			System.out.println();
		}
		for(int k = 1; k < c ; k++) {
			int i = r-1;
			int j = k;
			while( i>=0 && j < c ) {
				System.out.print(mat.get(i).get(j)+" ");
				i--;
				j++;
			}
			System.out.println();
		}
    }

    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t--!=0){
            int r = sc.nextInt();
            int c = sc.nextInt();

            // Create a List of null objects, where each object is List<Integer>
            List< List<Integer> > mat = new ArrayList<>();

            // It is important to init all one dimentional arrays
            for(int i=0;i<r;i++)
                mat.add(new ArrayList<>());
            
            for(int i=0;i<r;i++){
                for(int j=0;j<c;j++){
                    int x = sc.nextInt();
                    mat.get(i).add(x);  // Add x in the ith List to the end
                }
            }

            printDiagonally(mat);
            System.out.println();
        }
    }
}
//1
//9 2
//1 2 
//0 1 
//9 8 
//0 1 
//1 2 
//0 1 
//9 8 
//0 1 
//0 1 