package com.practice.day0.hour7;

public class FindInSortedMatrix {
	public static void main(String[] args) {
		int[][] arr = { { 1, 2, 3, 4 }, { 6, 8, 9, 10 }, { 7, 11, 12, 13 } };
		new FindInSortedMatrix().findNumberInSortedGrid(arr, 25);
	}
	void findNumberInSortedGrid(int arr[][], int key) {
		int r = 0;
		int c = arr[0].length-1;
		while(r<arr.length && c>=0 && arr[r][c] != key) {
			if(arr[r][c] < key) {
				r++;
			}
			else if(arr[r][c] > key) {
				c--;
			}
		}
		if(r==arr.length || c == -1) {
			System.out.println(-1);
		}
		else {
			System.out.println(r+" "+c);
		}
	}
}
