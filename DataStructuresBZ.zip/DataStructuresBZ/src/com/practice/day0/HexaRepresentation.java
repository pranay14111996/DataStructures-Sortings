package com.practice.day0;

import java.util.Scanner;

public class HexaRepresentation {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args)
	{
		while(sc.hasNext()) {
			int N = sc.nextInt();
			System.out.println(getHexa(N));
		}
	}

	private static String getHexa(int n) {
		if (n < 16) {
			if (n > 9) {
				return String.valueOf((char) ((n - 10) + 'A'));
			}
			return String.valueOf(n);
		}
		int rem = n % 16;
		String hexa = (rem > 9) ? String.valueOf((char) ((rem - 10) + 'A')) : String.valueOf(rem);
		return getHexa(n / 16) + "" + hexa;
	}
}
