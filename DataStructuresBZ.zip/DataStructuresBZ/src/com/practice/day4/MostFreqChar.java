package com.practice.day4;

import java.util.HashMap;
import java.util.Map;

public class MostFreqChar {
		char mostFrequentCharacter(char arr[]) {
		    Map<Character,Integer> map = new HashMap<>();
		  	if(arr.length == 0){
		    	return ' ';
		    }
		  	int maxCount = 0;
		  	char maxChar = ' ';
		  	for(char ch : arr){
		      	Integer count = map.get(ch);
		    	map.put(ch,count==null?1:count + 1);
		      	if(maxCount < (count==null?1:count + 1)){
		      		maxCount = (count==null?1:count + 1);
		        	maxChar = ch;
		        }
		    }
		  	return maxChar;
		}
	public static void main(String[] args) {
		System.out.println( new MostFreqChar().mostFrequentCharacter("goodyloopddpjd".toCharArray()) );
	}
}
