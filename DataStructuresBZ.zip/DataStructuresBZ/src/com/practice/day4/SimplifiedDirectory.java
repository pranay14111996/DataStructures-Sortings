package com.practice.day4;

import java.util.Stack;

public class SimplifiedDirectory {

	public static void main(String[] args) {
		String path = "/../";
		System.out.println(new SimplifiedDirectory().simplifiedDirectoryPath(path));
	}

	String simplifiedDirectoryPath(String path) {
		Stack<String> stk = new Stack<>();
		String simplePath = "";
		String p[] = path.split("/");
		for (String var : p) {
			if (var.equalsIgnoreCase("..")) {
				if (!stk.isEmpty())
					stk.pop();
			} else if (!var.trim().equalsIgnoreCase("") && !var.equalsIgnoreCase("/") && !var.equalsIgnoreCase(".")) {
				stk.push(var);
			}
		}
		if (stk.isEmpty()) {
			return "/";
		}
		while (!stk.isEmpty()) {
			simplePath = "/" + stk.pop() + simplePath;
		}
		return simplePath;
	}
}
