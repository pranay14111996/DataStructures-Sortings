package com.practice.day4;

import java.util.Scanner;
import java.util.Stack;
/**
 * O(1) TC & O(1) SC
 * 
 * We are taking 2x-max here cause
 * let, y= new_max_element
let, x= old_max_element
so:  y>x       (as newer min element is lesser than older min element)
adding y to both sides
=====>   2*y>x+y
subtracting x from both sides
=====> 2*y-x>y
this proves that 2*y-x will always be greater than the curr_minimum_element or new_min

Hence 2*x-curr_max always works as a flag here. If we put this 2*x-curr_max in stack and whenever this becomes top of stack if will always be
greater than curr_max.now using this curr_max can be updated using 2*curr_max - x.
@see <a href="https://www.youtube.com/watch?v=ZvaRHYYI0-4">Minimum Element in Stack in O(1) Space</a>

Also, with the approach above, you could have derived any other valid formula of your own.
 * */
public class StackMaxElement2 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Stack<Integer> stk = new Stack();
        int n = sc.nextInt();
        int max = Integer.MIN_VALUE;
        while(n-->0) {
        	int op = sc.nextInt();
        	if(op == 1) {
        		int x = sc.nextInt();
        		if(stk.isEmpty()) {
        			max = x;
        			stk.push(x);
        		}
        		else if( x <= max ) {
        			stk.push(x);
        		}
        		else {
        			stk.push(2*x - max);
        			max = x;
        		}
        	}
        	else if(op == 2) {
        		if(!stk.isEmpty()) {
        			int x = stk.pop();
        			if(x > max) {
        				max = 2*max - x;
        			}
        		}
        	}
        	else if(op == 3) {
        		if(!stk.isEmpty()) {
        			int x = stk.peek();
        			System.out.print( max +" " );
        		}
        			
        	}
        }
	}
}
/**
25
1 81
2
1 6
2
1 96
3
3
3
3
2
1 52
1 16
2
3
3
1 27
3
3
1 10
1 64
2
2
3
1 66
3
 * 
 * */
