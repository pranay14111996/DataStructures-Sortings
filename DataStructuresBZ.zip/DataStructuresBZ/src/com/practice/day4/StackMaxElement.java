package com.practice.day4;

import java.util.Scanner;
import java.util.Stack;

public class StackMaxElement {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack<Integer> stk = new Stack();
		Stack<Integer> maxStk = new Stack();
        int n = sc.nextInt(); 
        while(n-->0) {
        	int op = sc.nextInt();
        	if(op == 1) {
        		int x = sc.nextInt();
        		stk.push(x);
        		if(maxStk.isEmpty()) {
        			maxStk.push(x);
        		}
        		else if(x >= maxStk.peek()) {
        			maxStk.push(x);
        		}
        	}
        	else if(op == 2) {
        		if(!stk.isEmpty() && !maxStk.isEmpty()) {
        			if(stk.pop() >= maxStk.peek()) {
        				maxStk.pop();
        			}        			
        		}
        	}
        	else if(op == 3) {
        		if(!maxStk.isEmpty())
        			System.out.print( maxStk.peek() +" ");
        	}
        }
	}
}


/**
 *
8
1 9
1 81
1 19
3
2
3
2
3
 * */
