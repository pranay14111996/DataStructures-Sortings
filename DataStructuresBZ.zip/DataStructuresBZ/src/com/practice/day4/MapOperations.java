package com.practice.day4;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapOperations {

	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		int tests = sc.nextInt();
		for (int ti = 1; ti <= tests; ti++) {
			// For Every Test, We need to create new Stack
			Map<Integer, Integer> mp = new HashMap<>();

			int opsCount = sc.nextInt();
			for (int op = 1; op <= opsCount; op++) {
				int opType = sc.nextInt();
				if (opType == 0) {
					mp.put(sc.nextInt(), sc.nextInt());
				} else if (opType == 1) {
					System.out.print(mp.containsKey(sc.nextInt()) + " ");
				} else if (opType == 2) {
					System.out.print(mp.get(sc.nextInt()) + " ");
				} else if (opType == 3) {
					System.out.print(mp.size() + " ");
				} else if (opType == 4) {
					System.out.print(mp.remove(sc.nextInt()) + " ");
				}
			}
			System.out.println();
		}
	}
}
